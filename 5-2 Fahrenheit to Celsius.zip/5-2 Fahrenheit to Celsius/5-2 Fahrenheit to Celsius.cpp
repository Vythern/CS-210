// 5-2 Fahrenheit to Celsius.cpp
//Nate Dukes, April 1st, 2023.  


/*
 * Note that a space separates each city from its temperature.  
 * Assume the city�s name does not include any spaces or special characters (the name should consist of only a single word).  
 * Also assume the provided temperature is presented as an integer.  
 */



#include <iostream>
#include <fstream>
#include <vector>
#include <string>

int main()
{
    std::ifstream fahrenheitStream; //take input of fahrenheit temperatures from this file.  
    std::ofstream celciusStream; //output celsius temperatures to this file.  

    fahrenheitStream.open("FahrenheitTemperature.txt", std::ios::in); //open fahrenheit text document.  
    celciusStream.open("CelsiusTemperature.txt"); //create / open file for celsius temps.  

    if (fahrenheitStream.is_open() && celciusStream.is_open())
    {
        std::cout << "File successfully opened" << std::endl;

        std::vector<std::string> words;

        std::string tempName = " "; //used to read in all values.  
        std::string tempIntString = " "; //same

        while (fahrenheitStream >> tempName >> tempIntString) //get every word individually, none of the newlines or spaces.  
        {
            words.push_back(tempName);
            words.push_back(tempIntString);
        }

        for (int i = 0; i < words.size(); i++) //for each word, output a name, a temperature, and a newline to the file.  
        {
            if (i % 2 == 0) { celciusStream << words[i] << " "; }
            else if (i % 2 != 0) { celciusStream << ((((std::stof(words[i])) - 32 )/ 9) * 5) << std::endl; }
        }
    }
    else { std::cout << "It didn't open woohoo"; }
}