#pragma once
class Investment
{
	//A = P(1 + r/n)^nt

public:

	Investment(); //default constructor.  
	void basicReport();

	void depositReport();


private:
	int years = 0; //float because what if the user says like, 1.5 years?  
	float months = 0; //float because what if the user says like, 1.5 years?  
	float principalAmount = 0; //the initial amount of money invested.  
	float monthlyDeposit = 0; //the amount of monthly deposited money into the investment.  
	float currentBalance = 0;  //the current balance (used to track change over time)
	float interestEarned = 0; //the amount of accrued money from interest.  
	float interestRate = 0; //percentage interest rate multiplier.  
	float totalBalance = 0; //the total of the current principal amount, monthly deposits, and interest.  


	//function for getting these values initially by user input.  
	

	//function for displaying these values each month.  

};

