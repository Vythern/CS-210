// Project 2 CS 210.cpp
//Nate Dukes.  



/* ------------------------------------	*\
|* Display starting screen, all parts.	*|
|* Take input for each part.			*|
|* After receiving input, display		*|
|* all relevant data.					*|
|* Wait for user input to continue,		*|
|* Then return to starting screen.		*|
\* ------------------------------------	*/







#include <iostream>
#include "Investment.h"


int main()
{
		
	Investment testVestMent;
	Investment originalInvestment = testVestMent; //used to reset back to default after end.  
	int choice = 0;

	std::cout << std::endl << "View basic report or report with monthly deposit included?  \n1:  Basic\n2:  Monthly Included\n3:  New investment\n4:  Quit\nYour choice 1, 2, 3 or 3:  ";
	std::cin >> choice;
	while (choice != 4)
	{
		if (choice == 1)
		{
			testVestMent.basicReport();
		}
		else if (choice == 2)
		{
			testVestMent.depositReport();
		}
		else if (choice == 3)
		{
			Investment tempInvestment;
			testVestMent = tempInvestment;
			originalInvestment = testVestMent;
		}
		else
		{
			std::cout << std::endl << "Invalid choice.  Try again" << std::endl;
		}

		testVestMent = originalInvestment; //reset to initial numbers.  

		std::cout << std::endl << "View basic report or report with monthly deposit included?  \n1:  Basic\n2:  Monthly Included\n3:  New investment\n4:  Quit\nYour choice 1, 2, 3 or 3:  ";
		std::cin >> choice;
	}
}