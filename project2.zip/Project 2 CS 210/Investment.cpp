#include "Investment.h"
#include <iostream>
#include <string>




//(Opening Amount + Deposited Amount) * ((Interest Rate/100)/12)



void Investment::basicReport()
{
	//display a report of the balance based on user's input.  
	std::cout << "\tBalance and Interest Without Additional Monthly Deposits" << std::endl;
	std::cout << "==================================================================" << std::endl;
	std::cout << "\tYear\tYear End Balance\tInterest Earned This Month" << std::endl;
	std::cout << "------------------------------------------------------------------" << std::endl;
	for (int i = 1; i <= months; i++)
	{
		interestEarned = (currentBalance) * ((interestRate / 100) / 12);
		interestEarned *= 100;
		totalBalance = currentBalance + interestEarned;


		if (i % 12 == 1 || i == (months)) //only print info once per year.  remove this and the brackets to print for each month.  
		{									  //also print final balance
			if (i != 1) //don't show start of year balance, only start of next year / end of current year
			{
				float displayBalance = totalBalance;
				if (i != months) { displayBalance = displayBalance - interestEarned; } //accounts for end of month so it displays correctly without changing the calculation of the current month.  
				std::cout << "\t" << (i / 12); //output year (first month after each year of investment).  
				std::cout << "\t" << displayBalance << "\t\t\t" << interestEarned << std::endl;
			}
		}

		currentBalance = totalBalance;



		//print the year, followed by the balance at the end of the year(?), followed by the amount of interest earned.  
		//basically just print the same thing i times with i as the number of years.  
	}
}

void Investment::depositReport()
{
	//display a report of the balance based on user's input.  
	std::cout << "\tBalance and Interest With Additional Monthly Deposits" << std::endl;
	std::cout << "==================================================================" << std::endl;
	std::cout << "\tYear\tYear End Balance\tInterest Earned This Month" << std::endl;
	std::cout << "------------------------------------------------------------------" << std::endl;
	for (int i = 1; i <= months; i++)
	{
		interestEarned = (currentBalance + monthlyDeposit) * ((interestRate / 100) / 12);
		interestEarned *= 100;
		totalBalance = currentBalance + interestEarned + monthlyDeposit;

		if (i % 12 == 1 || i == (months)) //only print info once per year.  remove this and the brackets to print for each month.  
		{									  //also print final balance
			if (i != 1) //don't show start of year balance, only start of next year / end of current year
			{
				float displayBalance = totalBalance;
				if (i != months) { displayBalance = displayBalance - monthlyDeposit - interestEarned; } //accounts for end of month so it displays correctly without changing the calculation of the current month.  
				std::cout << "\t" << (i / 12); //output year (first month after each year of investment).  
				std::cout << "\t" << displayBalance << "\t\t\t" << interestEarned << std::endl;
			}
		}

		currentBalance = totalBalance;



		//print the year, followed by the balance at the end of the year(?), followed by the amount of interest earned.  
		//basically just print the same thing i times with i as the number of years.  
	}
}



Investment::Investment() //default contstructor, get investment information from user.  
{
	std::string dummy = " ";
	std::cout << "********************************\n********** Data Input **********" << std::endl;
	
	std::cout << "Initial Investment Amount:  ";
	std::cin >> principalAmount; //get principal investment
	currentBalance = principalAmount;

	std::cout << "Monthly Deposit:  ";
	std::cin >> monthlyDeposit; //get monthly deposit

	std::cout << "Annual Interest Rate (as a decimal, eg 0.10 = 10%):  ";
	std::cin >> interestRate; //get interest rate

	std::cout << "Number of years (whole numbers only):  ";	
	std::cin >> years;
	months = years * 12;
	
	std::cout << "Press any key followed by enter to continue . . .  " << std::flush;
	std::cin >> dummy; //dude, seriously, cin.ignore(int max..., cin.getchar, getline, I tried everything
					  //if it were me I'd just be using ncurses for console apps
						//but no matter what I do this stupid thing won't actually wait for a newline
						//so instead we have "Press any key (and then enter) to continue)" instead of just "press enter to continue".  
						//It sure would be a shame if somewhere in this program there was something stuck in the buffer, oh no.  
}
