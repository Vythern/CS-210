#include<iostream>
#include<string>




/* * * * * * * * * * *\
|* Nate Dukes.       *|
|* 18th/March, 2023  *|
|* CS 200 something  *|
\* * * * * * * * * * */




//converts numbers into strings, eg, 0 to 00, for clock readability.  
std::string twoDigitString(unsigned int n)
{
    if (n > 9) { return std::to_string(n); } //return digit as string.  
    else if (n >= 0 && n <= 9) { return ("0" + std::to_string(n)); }//return digit as string with 0 appended to it if between 0 and 9.  
    else { std::cout << "Invalid input." << std::endl; return "NULL"; }
}

//instead of using a string, we have a method to output characters n number of times.  Makes some logic easier to manage without for loops.  
std::string nCharString(size_t n, char c)
{
    std::string strToReturn = "";
    for (int i = 0; i < n; i++) { strToReturn += c; }
    return strToReturn;
}


//formatTime24 and formatTime12 take 3 ints to produce the correct time for the displayClocks() method.  
std::string formatTime24(unsigned int h, unsigned int m, unsigned int s)
{
    return (twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s));
}


std::string formatTime12(unsigned int h, unsigned int m, unsigned int s)
{
    if (h >= 0 && h < 12) //AM, from midnight to noon.  
    {
        if (h == 0) { h += 12; }
        return (twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " A M");
    }
    else if (h >= 12 && h < 24) //PM, from noon to midnight, excluding midnight.  
    {
        if (h - 12 == 0) { h += 12; }
        return (twoDigitString(h - 12) + ":" + twoDigitString(m) + ":" + twoDigitString(s) + " P M");
    }
    else { std::cout << "Invalid input." << std::endl; return "NULL"; }
}


//printMenu shows off the user's options for input during the main program loop.  
void printMenu(std::string strings[], unsigned int numStrings, unsigned char width)
{
    std::cout << nCharString(width, '*') << std::endl;
    for (int i = 0; i < numStrings; i++)
    {
        std::cout << "* " << (i + 1) << " - " << strings[i];
        std::cout << nCharString((width - 7 - strings[i].length()), ' ') << "*" << std::endl;

        if (i + 1 != numStrings) { std::cout << std::endl; }

    }
    std::cout << nCharString(width, '*');
}



//displayClocks prints the time in a pretty and digestible format based on current time.  
void displayClocks(unsigned int h, unsigned int m, unsigned int s)
{
    std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << std::endl;
    std::cout << "*" << nCharString(6, ' ') << "12-Hour Clock" << nCharString(6, ' ') << "*" << nCharString(3, ' ') << "*" << nCharString(6, ' ') << "24-Hour Clock" << nCharString(6, ' ') << "*" << std::endl;
    std::cout << "*" << nCharString(6, ' ') << formatTime12(h, m, s) << nCharString(7, ' ') << "*" << nCharString(3, ' ') << "*" << nCharString(8, ' ') << formatTime24(h, m, s) << nCharString(9, ' ') << "*" << std::endl;
    std::cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << std::endl;
}

int main() //start
{
    std::string time12 = "";
    std::string time24 = "";

    int h, m, s;

    std::cout << "Input the initial time in the format H M S, then press enter:  ";
    std::cin >> h >> m >> s; //get initial time.  
    std::cout << std::endl;
    
    
    std::string menuStrings[4] = { "Add Hour?", "Add Minute?", "Add Second?", "Exit?" };

    bool exit = false; //exit condition

    while (!exit) //core program loop, manages user input and calls relevant functions.  Additionally, the main loop handles incrementing of h, m, s.  
    {
        displayClocks(h, m, s); //in the loop, display time is always followed by display menu.  
        //so it makes sense to display time before the menu initially as well.  

        printMenu(menuStrings, 4, 26); //re-display menu and user input choices.  


        int userInput = 0; 
        std::cout << "\n\nEnter your choice:  ";
        std::cin >> userInput; //get user's menu choice.  
        std::cout << std::endl;

        switch (userInput)  //this switch handles the input, and adds time to the clock in a relevant manner.  
        {
            case 1:         //1, 2, and 3 all cause clock updates, and have the potential to go "over the limit" of the clock.  
                h += 1;     //I could put this into its own method but to be honest it doesn't matter to me.  
                if (h == 24) { h = 1; }
                break;

            case 2:         //minute increment, in the case of XX:59:XX, increments hour as well.  
                m += 1;
                if (m == 60)
                {
                    m = 0;
                    h += 1;
                    if (h == 24) { h = 1; }
                }
                break;
            case 3:         //second increment, in the case of XX:XX:59, increments minute, and the same as case 2, hour edge case.  
                s += 1;
                if (s == 60)
                {
                    s = 0;
                    m += 1;
                    if (m == 60)
                    {
                        m = 0;
                        h += 1;
                        if (h == 24) { h = 1; }
                    }
                }
                break;
            case 4:  
                exit = true; 
                break;
            default:  
                std::cout << "Invalid input, please retry with a 1, 2, 3, or 4, followed by pressing enter." << std::endl;
                break;
        }
        //display menu 
        //1, 2, 3, 4, options.  
        //if not exiting, then display time and then display menu based on input.  
        //else, exit.  
    }
}