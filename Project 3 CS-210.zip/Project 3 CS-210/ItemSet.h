#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <fstream> 

//ItemSet is used to get, track, and output the number of and frequency of unique item types occuring.  

class ItemSet
{
	public:
		ItemSet(std::vector<std::string> entries); //this class must be created with an array of words.  
		void getQuantity(std::string searchForStr); //return quantity of searchForStr present in data set.  
		void getItemList();  //output item list of current data.  
		void getHistogram(); //output histogram of current data.  

	private:
		std::vector<std::string> wordBank;
		std::vector<std::string> uniqueItems; //track each unique item type.  
		std::vector<int> duplicateCounts; //fir each unique item type, track the number of times they appear, as well.  
};