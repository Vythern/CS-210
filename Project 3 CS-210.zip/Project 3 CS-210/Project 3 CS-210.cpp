// Project 3 CS-210.cpp
//Nate Dukes.  
//April 15th, 2023.  


#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "ItemSet.h"

int main()
{
	//display menu:  
		//while(option != 4)
		//Get user input.  
		
			//option one:  
			//ask user what item they're looking for.  
			//Return number of times that the word appears in itemsList.txt

			//option 2:  
			//Print each unique item on the list followed by a number (for how many duplicates there are).  
			//eg, Potatoes 4, Pumpkins 5, Onions 3.  
			//update frequency.txt with this data.  

			//option 3:  
			//Histogram, same thing, except instead of a number, an asterisk for each duplicate.  
			//update frequency.txt with this data.  

			//option 4:  
			//exit program.  



	std::ifstream itemStream; //take input of items from this file.  
	
	itemStream.open("itemList.txt", std::ios::in); //open items list text document.  

	if (itemStream.is_open())
	{
		//std::cout << "File successfully opened" << std::endl; //uncomment to test if file is opening.  


		//start by getting all data into the backup file, then use that to handle everything.  

		std::string currentString = " ";
		std::vector<std::string> words;

		while (itemStream >> currentString) //get every word individually, none of the newlines or spaces.  
		{
			words.push_back(currentString); //get all words, then send it to the class object.  
		}
		//the itemSet class has a vector of each word, it has an array with each unique item id, and an array of integers tracking the unique item frequency.  


		ItemSet currentSet(words); //create item set, output data to frequency.dat.  

		int menuChoice = 0; //track user input.  

		while (menuChoice != 4) //while user is still viewing data, display menu and act accordingly.  
		{
			std::cout  << "Type 1, 2, 3, or 4, followed by enter to make your choice." << std::endl;
			std::cout << "Note each entry is capitalized and plural, eg Apples, not apple or apples" << std::endl;
			std::cout << "1.  Search for certain item and get quantity" << std::endl;	//use getQuantity method of ItemSet.  
			std::cout << "2.  Display item count" << std::endl;							//use getItemList method of ItemSet.  
			std::cout << "3.  Display histogram" << std::endl;							//use getHistogram method of ItemSet.  
			std::cout << "4.  Exit" << std::endl << "Your choice:  ";					//exit.  

			std::cin >> menuChoice;

			std::string searchStr = " "; //declare outside of switch, otherwise control passes.  
			
			switch (menuChoice)
			{
				case 1:
					std::cout << std::endl << "What are you searching for?  Type in a string to search for:  ";
					std::cin >> searchStr;
					currentSet.getQuantity(searchStr);
					break;

				case 2:
					currentSet.getItemList();
					break;

				case 3:
					currentSet.getHistogram();
					break;

				case 4:
					menuChoice = 4; 
					break;

				default:
					std::cout << "Invalid input, exiting." << std::endl;
					break;
			}
		}
		//*///
	}
	else { std::cout << "Failed to open file stream, exiting." << std::endl << std::flush; }
}