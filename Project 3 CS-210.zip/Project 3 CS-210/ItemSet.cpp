#include "ItemSet.h"




ItemSet::ItemSet(std::vector<std::string> entries)
{
	//upon creation, sift through each item in the entries list
	//then, if the item has not yet been encountered, add it to the uniqueItems list.  
	//if it has been encountered, then increment the duplicateCount.  
	//then, create a file with each unique item type followed by a space, and a number corresponding to the duplicate count.  


	bool duplicateFound = false;

	for (int i = 0; i < entries.size(); i++) //for each word, 
	{
		if (i >= 1) //don't do this check on the first iteration, or else out of bounds error.  
		{
			for (int j = 0; j < uniqueItems.size(); j++) //check if the current entry is equal to any previous entries.  
			{
				if (entries[i] == uniqueItems[j]) //if the current entry is equal to any of the unique items, then increase the duplicate count.  
				{
					duplicateCounts[j]++;
					duplicateFound = true; //set duplicate found to true, so that we don't add to the uniqueItems count.  
				}
			}
			if (!duplicateFound)
			{
				uniqueItems.push_back(entries[i]);
				duplicateCounts.push_back(1); //we have 1 item of type i to add to the duplicate count list.  
			}
			duplicateFound = false; //reset.  
		}
	}


	std::ofstream frequencyStream; //output records to this file.  
	frequencyStream.open("frequency.dat"); //create / open file for data output.  
	if (frequencyStream.is_open())
	{ 
		for (int l = 0; l < uniqueItems.size(); l++) 
		{ frequencyStream << uniqueItems[l] << " " << duplicateCounts[l] << std::endl; } 
	}
}



void ItemSet::getQuantity(std::string searchForStr) //return quantity of searchForStr present in data set.  
{
	bool foundItem = false;
	
	for (int n = 0; n < uniqueItems.size(); n++) //for each item
	{
		if (searchForStr.compare(uniqueItems[n]) == 0) //if the strings are the same, 
		{
			foundItem = true; //found a matching item, 
			std::cout << "There are " << duplicateCounts[n] << " " << searchForStr << "(s) in the data set." << std::endl; //output frequency of item.  
		}
	}
	


	if (foundItem == false)
	{
		std::cout << "No " << searchForStr << " found." << std::endl;
	}
}
void ItemSet::getItemList()  //output item list of current data.  
{
	for (int m = 0; m < uniqueItems.size(); m++)
	{
		std::cout << uniqueItems[m] << " " << duplicateCounts[m] << std::endl;
	}
}
void ItemSet::getHistogram() //output histogram of current data.  
{
	for (int k = 0; k < uniqueItems.size(); k++)
	{
		std::cout << uniqueItems[k] << " ";
		for(int p = 0; p < duplicateCounts[k]; p++) { std::cout << "*"; }
		std::cout << std::endl;
	}
}